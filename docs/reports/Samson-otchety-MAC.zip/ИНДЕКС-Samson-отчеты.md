# Индекс пакета: ядро и вся система Samson SBM

Корень: `~/Desktop/Samson-отчеты-2026-07-16/`  
Собран: 2026-07-16 · ветка `cursor/samson-production-core-f2e6` · commit `b893ce0`

## Читать сначала

1. `00-ОТЧЕТ-ЯДРО-И-СИСТЕМА.md` — сводный отчёт по ядру и всей системе  
2. `architecture/001-core-specification.md` — нормативная спецификация ядра (Frozen)  
3. `architecture/PREFLIGHT-READY-REPORT.md` — preflight 28/28  
4. `decisions/` — ADR-002 … ADR-005  
5. `packaging/` — docker-compose, Dockerfile, .env.example  
6. `schema/` — SQL-миграции 001–009  

## Дерево

```text
00-ОТЧЕТ-ЯДРО-И-СИСТЕМА.md
00-ИНДЕКС.md
00-КАРТА-МОДУЛЕЙ.md
ARCHITECTURE.md
MAINNET_DEPLOY.md
BATTLE_DEPLOYMENT_AUDIT.md
BACKLOG_TOKEN_SAFETY.md
MAC_BATCH_VALIDATION.md
architecture/
  001-core-specification.md
  PREFLIGHT-READY-REPORT.md
decisions/
  002-rag-architecture.md
  003-redteam-tools.md
  004-impact-simulation-remediation.md
  005-financial-impact-simulation.md
packaging/
  docker-compose.yml
  Dockerfile
  .env.example
schema/
  001_schema.sql … 009_drainer_purple_team.sql
forensics/
recon/
artifacts/
```

## Что намеренно не копировалось

- `docs/intel/*` drain malware samples  
- секреты / `.env` с ключами  
- массовые RAG emulation markdown dumps (`samson/rag/docs/emulation/*`)  
