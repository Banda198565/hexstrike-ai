# Samson SBM — полный отчёт: ядро и вся система

| Поле | Значение |
| --- | --- |
| Версия отчёта | `2.0.0` (полная перепись) |
| Дата UTC | 2026-07-16 |
| Ветка | `cursor/samson-production-core-f2e6` |
| Commit | `837a063`+ |
| PR | https://github.com/Banda198565/hexstrike-ai/pull/46 |
| Норматив ядра | `docs/architecture/001-core-specification.md` (Frozen 1.0.0) |
| Платформа | Authorized enterprise AI red-team / purple-team (on-prem) |

---

## 0. Как открыть на Mac Desktop

Из cloud/VPS на Finder Desktop Mac **напрямую писать нельзя**. На Mac выполни:

```bash
# вариант A — с VPS
scp -r root@78.27.235.70:/root/Desktop/Samson-отчеты-2026-07-16 ~/Desktop/
scp root@78.27.235.70:/root/Desktop/ОТЧЕТ-ЯДРО-И-СИСТЕМА-Samson.md ~/Desktop/

# вариант B — из git (после pull ветки)
cd /path/to/hexstrike-ai
git fetch origin cursor/samson-production-core-f2e6
git checkout cursor/samson-production-core-f2e6
cp -R docs/reports/samson-core-system-2026-07-16 ~/Desktop/
cp docs/reports/ОТЧЕТ-ЯДРО-И-СИСТЕМА.md ~/Desktop/
```

После этого в Finder: `Desktop/Samson-отчеты-2026-07-16/`.

---

## 1. Что это за система

**Samson SBM** — on-prem оркестратор purple-team аудита AI/financial агентов:

1. Берёт цели из desktop/container pool.
2. Обогащает через Shodan / FOFA / Arkham (budget-gated).
3. Гоняет injection payloads по in-scope HTTP.
4. Пишет evidence в PostgreSQL + pgvector (`vector(768)`).
5. Поднимает financial guardrail proxy и проверяет Round-2 (`drop` / `hitl`).
6. Делает **synthetic** Web3 drills только на локальном Anvil (sweeper / drainer).

Единая точка входа:

```bash
python3 samson/orchestrator.py <command>
```

---

## 2. Ядро (`samson/core/`)

| Модуль | Роль |
| --- | --- |
| `config.py` | `SamsonSettings` — DB, Ollama, Shodan/Arkham/FOFA, Web3, guardrail |
| `database.py` | SQLAlchemy pool, audit repository |
| `target_loader.py` | ingest: `~/Desktop/тест ЦЕЛИ` → env → `/data/pentest/targets` |
| `scope.py` | `ScopeEnforcer` — operator + URL scope |
| `payloads.py` | registry payloads |
| `http_client.py` | shared HTTP |
| `errors.py` | `ConfigurationError` и доменные ошибки |

Ядро **не** атакует само — оно даёт конфиг, scope, ingest, persistence.

---

## 3. Оркестратор и pipeline

| Путь | Роль |
| --- | --- |
| `samson/orchestrator.py` | CLI façade всех команд |
| `samson/pipeline/continuous_audit.py` | helpers continuous-audit |
| `samson/pipeline/rag_payload_loader.py` | payloads из RAG каталога |

### CLI (полный каталог)

```text
migrate
serve
health
garak-scan
rag-retrieve
pyrit-eval
guardrail-deploy
guardrail-proxy-serve
run-continuous-audit
run-bulk-audit
shodan-lookup
arkham-lookup
fofa-lookup
fofa-hunt-redis
sweeper-purple-team
drainer-purple-team
```

---

## 4. Главный purple-team цикл

`run-continuous-audit` / внутри `run-bulk-audit`:

```text
1. Payload Registry          → ExecutionPayload[]
2. AdversaryEmulationExecutor (httpx, scope-checked)
3. Persist + vector(768)     → Postgres/pgvector
4. RAG Oracle                → explainability (brief может soft-skip)
5. Guardrail deploy          → proxy :8787
6. Round-2 replay            → after_action ∈ {drop, hitl}
7. deployer.close()          → освобождение сокета
```

Assertion:

- нет breach → PASS;
- каждый breach → guardrail deployed + proxy `drop|hitl` → PASS; иначе FAIL.

---

## 5. Red-team / recon / Web3

| Подсистема | Модули | Команда | Примечание |
| --- | --- | --- | --- |
| HTTP emulation | `adversary_executor.py` | continuous/bulk | scoped httpx |
| Shodan | `shodan_collector.py` | `shodan-lookup` | cache → rate 5s → reserve ≤5 |
| Arkham | `arkham_*.py` | `arkham-lookup` | risk → `web3_recon_artifacts`; balance gate |
| FOFA | `hybrid_recon.py` | `fofa-lookup`, `fofa-hunt-redis` | Redis:6379 hunt |
| Guardrail | `guardrail/*` | deploy / proxy-serve | IBAN + HITL |
| Validation node | `validation_node.py` | Web3 diversion drill | **Anvil only** |
| Sweeper PT | `sweeper_purple_team.py` | `sweeper-purple-team` | native full-balance Anvil |
| Drainer PT | `drainer_purple_team.py` | `drainer-purple-team` | ERC20/USDT Anvil; TRX = IOC defense |
| Redis drill | `redis_executor.py` | (executor) | unauth context exposure |
| Garak/PyRIT/ATLAS | `garak/`, `pyrit/`, `atlas/` | scan / eval | model health & risk |

### Политика Web3 (жёсткая)

- Attack-пути sweeper/drainer — **только** local Anvil/Hardhat (`31337` / `1337`).
- Mainnet / BSC / TRON live drain malware **не** operational модули.
- Секреты только в env (`SAMSON_*`).

---

## 6. RAG

Путь: `samson/rag/`

| Компонент | Роль |
| --- | --- |
| `rag_oracle.py` | `retrieve_context` / `build_brief` / `write_report_context` |
| `search/ingest.py` | chunk + embed |
| `search/retrieve.py` | vector search |
| `search/rerank.py` | rerank |
| Postgres | `embeddings.embedding vector(768)` + HNSW |

ADR: `docs/decisions/002-rag-architecture.md`.

---

## 7. AI Firewall (guardrail)

| Компонент | Деталь |
| --- | --- |
| Proxy | aiohttp reverse-proxy, default `:8787` |
| IBAN | extract → whitelist → ISO13616 mod-97 |
| HITL | `guardrail_pending_actions` |
| Decisions | `allow` / `drop` / `hitl` |

Compose-сервис: `samson-guardrail-proxy`.

---

## 8. Docker — вся on-prem система

| Сервис | Порт host | Роль |
| --- | --- | --- |
| `samson-db` | `127.0.0.1:5432` | Postgres 15 + pgvector |
| `samson-anvil` | `127.0.0.1:8545` | Foundry Anvil chain_id=31337 |
| `samson-core-engine` | — | `orchestrator.py serve` |
| `samson-guardrail-proxy` | `8787` | long-lived firewall |

Сеть `samson_net`, volume `samson_db_data`.

Внешние зависимости хоста: Arena `:8080`, Ollama `:11434`.

```bash
docker compose up -d --build
python3 samson/orchestrator.py migrate
python3 samson/orchestrator.py health
```

---

## 9. Схема БД (миграции 001–009)

| # | Файл | Содержание |
| --- | --- | --- |
| 001 | `001_schema.sql` | RAG, exercise, audit |
| 002 | `002_adversary_emulation.sql` | emulation + embeddings |
| 003 | `003_guardrail_proxy.sql` | deployments + HITL |
| 004 | `004_shodan_recon.sql` | budgets + Shodan artifacts |
| 005 | `005_synthetic_emulation.sql` | synthetic Web3 |
| 006 | `006_arkham_recon.sql` | `web3_recon_artifacts` |
| 007 | `007_fofa_recon.sql` | FOFA cache |
| 008 | `008_sweeper_purple_team.sql` | sweeper runs |
| 009 | `009_drainer_purple_team.sql` | drainer suite runs |

---

## 10. Ключевые contracts

Из `samson/redteam/schemas.py`:

- Emulation: `AdversaryTargetContext`, `ExecutionPayload`, `AdversaryEmulationResult`
- Audit: `ContinuousAuditRequest/Result`, `BulkAuditMatrix`
- Guardrail: `GuardrailEnforcementConfig`, proxy decisions
- Recon: `ApiCreditBudget`, `ShodanReconArtifact`, Arkham intel
- Purple-team: `SweeperPurpleTeamResult`, `DrainerFamilyResult`, `DrainerPurpleTeamResult`

---

## 11. ADR и нормативные документы

| ID | Документ |
| --- | --- |
| Core Spec | `architecture/001-core-specification.md` |
| Preflight | `architecture/PREFLIGHT-READY-REPORT.md` (28/28) |
| ADR-002 | RAG architecture |
| ADR-003 | Red-team tools |
| ADR-004 | Impact + remediation |
| ADR-005 | Financial impact simulation |
| Evolve | `ARCHITECTURE.md` (dummy → agent layers) |

---

## 12. Проверки (зафиксированные)

| Контур | Результат |
| --- | --- |
| Continuous-audit (freeze baseline) | 10/10 PASS |
| Preflight Ready | 28/28 PASS |
| `sweeper-purple-team` | ASSERTION PASS (Anvil) |
| `drainer-purple-team --family all` | ASSERTION PASS (EVM+USDT+TRX IOC) |

---

## 13. Безопасность

1. Scope + operator first.  
2. No secrets in git.  
3. OSINT: cache-first, rate-limit, credit floor.  
4. HITL на неоднозначный financial egress.  
5. Web3 attack drills — local chain only.  
6. Postgres bind `127.0.0.1` в compose.

---

## 14. Карта пакета на Desktop (после scp)

```text
Samson-отчеты-2026-07-16/
  00-ОТЧЕТ-ЯДРО-И-СИСТЕМА.md   ← этот документ
  00-ИНДЕКС.md
  00-КАРТА-МОДУЛЕЙ.md
  architecture/
  decisions/
  packaging/   # docker-compose, Dockerfile, .env.example
  schema/      # 001…009.sql
  forensics/
  recon/
  artifacts/
```

Конец отчёта v2.0.0.
